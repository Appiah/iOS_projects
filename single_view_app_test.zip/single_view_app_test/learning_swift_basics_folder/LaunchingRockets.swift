//
//  LaunchingRockets.swift
//  
//
//  Created by Emmanuel Appiah on 15/07/2020.
//
//

import Foundation

class LaunchingRockets {

    var fuelLevel = 100
    var name="Jane Janis"
    
    func cruise(){
        //code to initiate cruising
        print("Crusing is initiated for \(name)")
    }
    
    func thrust(){
        //code to initiate rocket thrusters
        print("Rocket thursters initiated for \(name)")
    }

}

var launchr = LaunchingRockets()
launchr
