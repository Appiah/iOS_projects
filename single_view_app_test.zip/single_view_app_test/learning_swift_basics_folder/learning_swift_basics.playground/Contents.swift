//: Playground - noun: a place where people can play

import UIKit

//This project is created to help you do a quick recap of swift coding
//for Xcode projects ,ie. for iOS apps development

var str = "Hello, playground"
//this is a comment and the code would not show or run in the program
/* this is a multiple
    line of lines
    comment and this would not show or run in the code
 */
print (str)
str = "new variable declaration"
print (str)

let con = "more data"
//this is not allowed : con = "modified data", a 'let' would not allow you to reassign a new data to a 'let' variable
print (con)

var b = false
print (b)

var c:Bool = true
print (c)

var i = 32
i = 0
i = -10

var j:Int = 42


var f = 0.2345

//double is a lot more precise than float : hint : bsilfd

var g:Double = 0.466574837

func sayHello(){
    print ("hello John")
}

sayHello()

//parameters would have to be called with the variable names in place :
func sumAB(a:Int, b:Int){
    print(a+b)
}

sumAB(a:1, b:4)


//to use the parameters directly :
func sumAB_direct(_ a:Int, _ b:Int){
    print(a+b)
}
sumAB_direct(3, 7)

//functional programming in swift
func sumAB_fxnl(x:Int, y:Int) -> Int {

    return x+y

}

sumAB_fxnl(x: 5, y: 9)


//functional programming with a direct parameter input
func sumAB_fxnl_direct(_ x:Int, _ y:Int)->Int{
    return x+y;
}

sumAB_fxnl_direct(8, 9)




