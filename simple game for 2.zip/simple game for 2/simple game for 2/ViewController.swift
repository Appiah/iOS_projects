//
//  ViewController.swift
//  simple game for 2
//
//  Created by Emmanuel Appiah on 23/07/2020.
//  Copyright © 2020 Emmanuel Appiah. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

